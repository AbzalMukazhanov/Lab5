'use strict';

process.stdin.resume();
process.stdin.setEncoding('utf-8');

let inputString = '';
let currentLine = 0;

process.stdin.on('data', inputStdin => {
    inputString += inputStdin;
});

process.stdin.on('end', _ => {
    inputString = inputString.trim().split('\n').map(string => {
        return string.trim();
    });
    
    main();    
});

function readLine() {
    return inputString[currentLine++];
}
function getSecondLargest(nums) {
    let firstLargest = -1;
    let secondLargest = -1;
    for (let i = 0; i < nums.length; i++) {
        const currentNum = nums[i];
        if (currentNum > firstLargest) {
            secondLargest = firstLargest;
            firstLargest = currentNum;
        } else if (currentNum < firstLargest && currentNum > secondLargest) {
            secondLargest = currentNum;
        }
    }
    return secondLargest;
}

function main() {
    const n = +(readLine());
    const nums = readLine().split(' ').map(Number);
    
    console.log(getSecondLargest(nums));
}