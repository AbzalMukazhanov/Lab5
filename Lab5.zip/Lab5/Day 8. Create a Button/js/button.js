let button = document.getElementById('btn');
i=0;
function clc(){
    i++;
    button.textContent=i;     
    
}